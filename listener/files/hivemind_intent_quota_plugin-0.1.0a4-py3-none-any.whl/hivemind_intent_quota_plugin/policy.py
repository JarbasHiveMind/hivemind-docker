from __future__ import annotations

import dataclasses
import hashlib
import os
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional

from hivemind_plugin_manager import PolicyPlugin, Verdict

from hivemind_intent_quota_plugin.storage import QuotaCounter, QuotaResult, create_storage


DEFAULT_MESSAGE_TYPES = ["recognizer_loop:utterance"]


def _as_list(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    return [str(item) for item in value]


def _optional_int(value: Any) -> Optional[int]:
    if value is None or value == "":
        return None
    return int(value)


@dataclasses.dataclass
class Limits:
    daily_limit: Optional[int] = None
    monthly_limit: Optional[int] = None


@dataclasses.dataclass(frozen=True)
class LegacyPolicyDecision:
    allowed: bool = True
    code: str = ""
    reason: str = ""
    data: Dict[str, Any] = dataclasses.field(default_factory=dict)


class IntentQuotaPolicy(PolicyPlugin):
    """Policy plugin that limits matching bus messages by a trusted context subject."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.limits = Limits(
            daily_limit=_optional_int(self.config.get("daily_limit")),
            monthly_limit=_optional_int(self.config.get("monthly_limit")),
        )
        self.subject_field = str(self.config.get("subject_field", "api_key"))
        self.subject_limits = dict(
            self.config.get("subject_limits")
            or self.config.get("api_key_limits")
            or {}
        )
        self.daily_limit_hash_key = self._optional_string(
            self.config.get("daily_limit_hash_key")
        )
        self.monthly_limit_hash_key = self._optional_string(
            self.config.get("monthly_limit_hash_key")
        )
        self.hash_limit_subjects = bool(self.config.get("hash_limit_subjects", False))
        self.message_types = set(
            _as_list(self.config.get("message_types", DEFAULT_MESSAGE_TYPES))
        )
        self.message_type_prefixes = tuple(_as_list(self.config.get("message_type_prefixes")))
        self.message_type_regex = [
            re.compile(pattern) for pattern in _as_list(self.config.get("message_type_regex"))
        ]
        self.count_on = str(self.config.get("count_on", "authorize")).lower()
        if self.count_on not in ("authorize", "record"):
            raise ValueError("count_on must be 'authorize' or 'record'")
        self.hash_subjects = bool(
            self.config.get("hash_subjects", self.config.get("hash_api_keys", True))
        )
        self.exempt_admin = bool(self.config.get("exempt_admin", False))
        self.exempt_subjects = set(
            _as_list(self.config.get("exempt_subjects", self.config.get("exempt_api_keys")))
        )
        self.storage = create_storage(self._storage_config())

    def review(self, message, client) -> Verdict:
        if not self._should_count(message, client):
            return Verdict.allow()

        subject = self._subject(client)
        if not subject:
            return Verdict.deny(
                "intent_quota_missing_subject",
                f"intent quota requires {self.subject_field}",
            )

        counters = self._counters_for(subject, client)
        if not counters:
            return Verdict.allow()

        identity = self._storage_identity(subject)
        result = (
            self._check_only(identity, counters)
            if self.count_on == "record"
            else self.storage.reserve(identity, counters)
        )

        if result.allowed:
            return Verdict.allow()
        return self._denied_verdict(message, result)

    def observe(self, message, client) -> None:
        if self.count_on != "record" or not self._should_count(message, client):
            return
        subject = self._subject(client)
        if not subject:
            return
        counters = self._counters_for(subject, client)
        if counters:
            self.storage.increment(self._storage_identity(subject), counters)

    def authorize_bus_message(self, message, context):
        """Compatibility shim for callers that still use the old policy hook."""
        return self._legacy_decision(self.review(message, context))

    def record_bus_message(self, message, context, result=None):
        """Compatibility shim for callers that still use the old policy hook."""
        self.observe(message, context)

    @staticmethod
    def _legacy_decision(verdict: Verdict) -> LegacyPolicyDecision:
        return LegacyPolicyDecision(
            allowed=not verdict.denied,
            code=verdict.code,
            reason=verdict.reason,
            data=verdict.data,
        )

    def _check_only(self, identity: str, counters: Iterable[QuotaCounter]) -> QuotaResult:
        counters = list(counters)
        counts = self.storage.get_counts(identity, counters)
        for counter in counters:
            if counts.get(counter.key, 0) >= counter.limit:
                return QuotaResult(False, counts, counter)
        return QuotaResult(True, counts)

    def _should_count(self, message, context) -> bool:
        if self._is_exempt(context):
            return False
        msg_type = getattr(message, "msg_type", "")
        if msg_type in self.message_types:
            return True
        if self.message_type_prefixes and msg_type.startswith(self.message_type_prefixes):
            return True
        return any(pattern.search(msg_type) for pattern in self.message_type_regex)

    def _is_exempt(self, context) -> bool:
        subject = self._subject(context)
        if subject and subject in self.exempt_subjects:
            return True
        user = self._user(context)
        return bool(
            self.exempt_admin
            and (
                getattr(user, "is_admin", False)
                or getattr(context, "is_admin", False)
            )
        )

    def _subject(self, context) -> str:
        if self.subject_field in ("api_key", "user.api_key"):
            return self._api_key(context)

        user = self._user(context)
        client = self._client(context)
        if self.subject_field.startswith("user."):
            value = self._get_dotted(user, self.subject_field[len("user."):])
        elif self.subject_field.startswith("client."):
            value = self._get_dotted(client, self.subject_field[len("client."):])
        else:
            value = self._get_dotted(user, self.subject_field)
            if value is None:
                value = self._get_dotted(client, self.subject_field)

        return str(value).strip() if value is not None else ""

    @staticmethod
    def _get_dotted(source, path: str):
        current = source
        for part in path.split("."):
            if current is None:
                return None
            if isinstance(current, dict):
                current = current.get(part)
            else:
                current = getattr(current, part, None)
        return current

    def _api_key(self, context) -> str:
        user = self._user(context)
        client = self._client(context)
        return (
            getattr(user, "api_key", None)
            or getattr(context, "api_key", None)
            or getattr(context, "key", None)
            or getattr(client, "key", None)
            or getattr(client, "api_key", None)
            or ""
        )

    def _user(self, context):
        user = getattr(context, "user", None)
        if user is not None:
            return user
        resolved = getattr(context, "_resolved_user", None)
        if resolved is not None:
            return resolved
        db = getattr(self.hm_protocol, "db", None)
        if db is not None and hasattr(context, "resolve_user"):
            try:
                return context.resolve_user(db)
            except Exception:
                return None
        return None

    @staticmethod
    def _client(context):
        return getattr(context, "client", None) or context

    @staticmethod
    def _optional_string(value: Any) -> Optional[str]:
        if not isinstance(value, str):
            return None
        value = value.strip()
        return value or None

    def _limits_for(self, subject: str) -> Limits:
        override = self.subject_limits.get(subject) or {}
        daily_limit = self._subject_limit_from_hash(self.daily_limit_hash_key, subject)
        monthly_limit = self._subject_limit_from_hash(self.monthly_limit_hash_key, subject)
        return Limits(
            daily_limit=_optional_int(
                override.get(
                    "daily_limit",
                    daily_limit if daily_limit is not None else self.limits.daily_limit,
                )
            ),
            monthly_limit=_optional_int(
                override.get(
                    "monthly_limit",
                    monthly_limit if monthly_limit is not None else self.limits.monthly_limit,
                )
            ),
        )

    def _subject_limit_from_hash(self, hash_key: Any, subject: str) -> Optional[int]:
        if not hash_key:
            return None
        lookup_subject = self._storage_identity(subject) if self.hash_limit_subjects else subject
        return self.storage.get_subject_limit(str(hash_key), lookup_subject)

    def _counters_for(self, subject: str, context=None) -> List[QuotaCounter]:
        limits = self._limits_for(subject)
        now = datetime.now(timezone.utc)
        counters = []
        if limits.daily_limit is not None:
            counters.append(
                QuotaCounter(
                    name="daily",
                    key=f"daily:{now:%Y-%m-%d}",
                    limit=limits.daily_limit,
                    reset_after=self._seconds_until(now, now.date() + timedelta(days=1)),
                )
            )
        if limits.monthly_limit is not None:
            next_month = datetime(now.year + int(now.month == 12), 1 if now.month == 12 else now.month + 1, 1, tzinfo=timezone.utc)
            counters.append(
                QuotaCounter(
                    name="monthly",
                    key=f"monthly:{now:%Y-%m}",
                    limit=limits.monthly_limit,
                    reset_after=max(1, int((next_month - now).total_seconds())),
                )
            )
        return counters

    @staticmethod
    def _seconds_until(now: datetime, reset_date) -> int:
        reset = datetime.combine(reset_date, datetime.min.time(), tzinfo=timezone.utc)
        return max(1, int((reset - now).total_seconds()))

    def _storage_identity(self, subject: str) -> str:
        if not self.hash_subjects:
            return subject
        return hashlib.sha256(subject.encode("utf-8")).hexdigest()

    def _storage_config(self) -> Dict[str, Any]:
        if "storage" in self.config and self.config["storage"] is not None:
            return dict(self.config["storage"] or {})
        storage_config = self._storage_config_from_database(self._server_database_config()) or {}
        quota_key_prefix = self.config.get("quota_key_prefix") or self.config.get("key_prefix")
        if quota_key_prefix and storage_config.get("backend") == "redis":
            storage_config["key_prefix"] = str(quota_key_prefix)
        return storage_config

    @staticmethod
    def _server_database_config() -> Dict[str, Any]:
        try:
            from hivemind_core.config import get_server_config
        except ImportError:
            return {}

        database_config = get_server_config().get("database") or {}
        return database_config if isinstance(database_config, dict) else {}

    @classmethod
    def _storage_config_from_database(cls, database_config: Dict[str, Any]) -> Dict[str, Any]:
        module = str(database_config.get("module") or "").strip()
        plugin_config = database_config.get(module) if module else None
        if not isinstance(plugin_config, dict):
            plugin_config = database_config.get("config")
        if not isinstance(plugin_config, dict):
            plugin_config = {}

        if module == "hivemind-redis-db-plugin":
            return cls._redis_storage_config(plugin_config)
        if module == "hivemind-sqlite-db-plugin":
            return cls._file_storage_config(plugin_config, backend="sqlite", suffix="sqlite3")
        if module == "hivemind-json-db-plugin":
            return cls._file_storage_config(plugin_config, backend="jsondb", suffix="json")
        return {}

    @staticmethod
    def _redis_storage_config(plugin_config: Dict[str, Any]) -> Dict[str, Any]:
        storage_config: Dict[str, Any] = {"backend": "redis"}
        for key in (
            "url",
            "host",
            "port",
            "db",
            "username",
            "password",
            "cluster_nodes",
            "cluster_hash_tag",
            "ssl",
            "use_ssl",
            "ssl_certfile",
            "ssl_keyfile",
            "ssl_ca_certs",
            "ssl_cert_reqs",
            "ssl_check_hostname",
        ):
            if key in plugin_config:
                storage_config[key] = plugin_config[key]

        key_prefix = plugin_config.get("quota_key_prefix") or plugin_config.get("key_prefix")
        if not key_prefix:
            database_prefix = plugin_config.get("index_prefix") or plugin_config.get("prefix")
            if database_prefix:
                key_prefix = f"{str(database_prefix).rstrip(':')}:intent-quota"
        if key_prefix:
            storage_config["key_prefix"] = key_prefix
        return storage_config

    @staticmethod
    def _file_storage_config(
        plugin_config: Dict[str, Any],
        *,
        backend: str,
        suffix: str,
    ) -> Dict[str, Any]:
        if plugin_config.get("path"):
            path = str(plugin_config["path"])
        else:
            name = str(plugin_config.get("name") or "clients")
            subfolder = str(plugin_config.get("subfolder") or "hivemind-core")
            path = os.path.join(
                IntentQuotaPolicy._xdg_data_home(),
                subfolder,
                f"{name}-intent-quotas.{suffix}",
            )
        return {"backend": backend, "path": path}

    @staticmethod
    def _xdg_data_home() -> str:
        try:
            from ovos_utils.xdg_utils import xdg_data_home
        except ImportError:
            return os.path.expanduser("~/.local/share")
        return xdg_data_home()

    @staticmethod
    def _denied_verdict(message, result: QuotaResult) -> Verdict:
        counter = result.exceeded
        used = result.counts.get(counter.key, 0) if counter else 0
        return Verdict.deny(
            "intent_quota_exceeded",
            f"{counter.name} intent quota exceeded" if counter else "intent quota exceeded",
            period=counter.name if counter else "",
            limit=counter.limit if counter else 0,
            used=used,
            reset_after=counter.reset_after if counter else 0,
            request_type=getattr(message, "msg_type", ""),
        )
