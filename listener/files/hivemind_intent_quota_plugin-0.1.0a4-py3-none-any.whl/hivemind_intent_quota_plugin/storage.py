from __future__ import annotations

import abc
import dataclasses
import fcntl
import hashlib
import json
import os
import sqlite3
import tempfile
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, Optional, Sequence


@dataclasses.dataclass(frozen=True)
class QuotaCounter:
    name: str
    key: str
    limit: int
    reset_after: int


@dataclasses.dataclass(frozen=True)
class QuotaResult:
    allowed: bool
    counts: Dict[str, int]
    exceeded: Optional[QuotaCounter] = None


class QuotaStorage(abc.ABC):
    @abc.abstractmethod
    def get_counts(self, identity: str, counters: Sequence[QuotaCounter]) -> Dict[str, int]:
        raise NotImplementedError

    @abc.abstractmethod
    def increment(self, identity: str, counters: Sequence[QuotaCounter]) -> Dict[str, int]:
        raise NotImplementedError

    def reserve(self, identity: str, counters: Sequence[QuotaCounter]) -> QuotaResult:
        counts = self.get_counts(identity, counters)
        for counter in counters:
            if counts.get(counter.key, 0) >= counter.limit:
                return QuotaResult(False, counts, counter)
        return QuotaResult(True, self.increment(identity, counters))

    def get_subject_limit(self, hash_key: str, subject: str) -> Optional[int]:
        return None


class MemoryQuotaStorage(QuotaStorage):
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self._lock = threading.RLock()
        self._data: Dict[str, Dict[str, int]] = {}

    def get_counts(self, identity: str, counters: Sequence[QuotaCounter]) -> Dict[str, int]:
        with self._lock:
            usage = self._data.get(identity, {})
            return {counter.key: int(usage.get(counter.key, 0)) for counter in counters}

    def increment(self, identity: str, counters: Sequence[QuotaCounter]) -> Dict[str, int]:
        with self._lock:
            usage = self._data.setdefault(identity, {})
            for counter in counters:
                usage[counter.key] = int(usage.get(counter.key, 0)) + 1
            return {counter.key: int(usage.get(counter.key, 0)) for counter in counters}

    def reserve(self, identity: str, counters: Sequence[QuotaCounter]) -> QuotaResult:
        with self._lock:
            counts = self.get_counts(identity, counters)
            for counter in counters:
                if counts.get(counter.key, 0) >= counter.limit:
                    return QuotaResult(False, counts, counter)
            return QuotaResult(True, self.increment(identity, counters))


class JsonQuotaStorage(QuotaStorage):
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        config = config or {}
        default_path = "~/.local/share/hivemind-intent-quota-plugin/quotas.json"
        self.path = Path(os.path.expanduser(config.get("path", default_path)))
        self.lock_path = Path(str(self.path) + ".lock")

    @contextmanager
    def _locked_data(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.lock_path, "a+") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            try:
                data = {"version": 1, "usage": {}}
                if self.path.is_file():
                    with open(self.path) as f:
                        loaded = json.load(f)
                        if isinstance(loaded, dict):
                            data.update(loaded)
                data.setdefault("usage", {})
                yield data
                fd, tmp_name = tempfile.mkstemp(
                    prefix=self.path.name + ".", suffix=".tmp", dir=str(self.path.parent)
                )
                try:
                    with os.fdopen(fd, "w") as tmp:
                        json.dump(data, tmp, sort_keys=True)
                        tmp.write("\n")
                    os.replace(tmp_name, self.path)
                finally:
                    if os.path.exists(tmp_name):
                        os.unlink(tmp_name)
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)

    def get_counts(self, identity: str, counters: Sequence[QuotaCounter]) -> Dict[str, int]:
        with self._locked_data() as data:
            usage = data["usage"].get(identity, {})
            return {counter.key: int(usage.get(counter.key, 0)) for counter in counters}

    def increment(self, identity: str, counters: Sequence[QuotaCounter]) -> Dict[str, int]:
        with self._locked_data() as data:
            usage = data["usage"].setdefault(identity, {})
            for counter in counters:
                usage[counter.key] = int(usage.get(counter.key, 0)) + 1
            return {counter.key: int(usage.get(counter.key, 0)) for counter in counters}

    def reserve(self, identity: str, counters: Sequence[QuotaCounter]) -> QuotaResult:
        with self._locked_data() as data:
            usage = data["usage"].setdefault(identity, {})
            counts = {counter.key: int(usage.get(counter.key, 0)) for counter in counters}
            for counter in counters:
                if counts.get(counter.key, 0) >= counter.limit:
                    return QuotaResult(False, counts, counter)
            for counter in counters:
                usage[counter.key] = counts.get(counter.key, 0) + 1
                counts[counter.key] = usage[counter.key]
            return QuotaResult(True, counts)


class SQLiteQuotaStorage(QuotaStorage):
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        config = config or {}
        default_path = "~/.local/share/hivemind-intent-quota-plugin/quotas.sqlite3"
        self.path = Path(os.path.expanduser(config.get("path", default_path)))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(
            str(self.path),
            timeout=float(config.get("timeout", 30)),
            isolation_level=None,
            check_same_thread=False,
        )
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS quota_usage ("
            "identity TEXT NOT NULL, "
            "counter TEXT NOT NULL, "
            "count INTEGER NOT NULL DEFAULT 0, "
            "updated_at REAL NOT NULL, "
            "PRIMARY KEY(identity, counter)"
            ")"
        )

    def get_counts(self, identity: str, counters: Sequence[QuotaCounter]) -> Dict[str, int]:
        with self._lock:
            counts = {}
            for counter in counters:
                row = self._conn.execute(
                    "SELECT count FROM quota_usage WHERE identity = ? AND counter = ?",
                    (identity, counter.key),
                ).fetchone()
                counts[counter.key] = int(row[0]) if row else 0
            return counts

    def increment(self, identity: str, counters: Sequence[QuotaCounter]) -> Dict[str, int]:
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                now = time.time()
                for counter in counters:
                    self._conn.execute(
                        "INSERT INTO quota_usage(identity, counter, count, updated_at) "
                        "VALUES (?, ?, 1, ?) "
                        "ON CONFLICT(identity, counter) DO UPDATE SET "
                        "count = count + 1, updated_at = excluded.updated_at",
                        (identity, counter.key, now),
                    )
                self._conn.commit()
            except Exception:
                self._conn.rollback()
                raise
            return self.get_counts(identity, counters)

    def reserve(self, identity: str, counters: Sequence[QuotaCounter]) -> QuotaResult:
        with self._lock:
            self._conn.execute("BEGIN IMMEDIATE")
            try:
                counts = {}
                for counter in counters:
                    row = self._conn.execute(
                        "SELECT count FROM quota_usage WHERE identity = ? AND counter = ?",
                        (identity, counter.key),
                    ).fetchone()
                    counts[counter.key] = int(row[0]) if row else 0
                    if counts[counter.key] >= counter.limit:
                        self._conn.rollback()
                        return QuotaResult(False, counts, counter)

                now = time.time()
                for counter in counters:
                    self._conn.execute(
                        "INSERT INTO quota_usage(identity, counter, count, updated_at) "
                        "VALUES (?, ?, 1, ?) "
                        "ON CONFLICT(identity, counter) DO UPDATE SET "
                        "count = count + 1, updated_at = excluded.updated_at",
                        (identity, counter.key, now),
                    )
                    counts[counter.key] += 1
                self._conn.commit()
                return QuotaResult(True, counts)
            except Exception:
                self._conn.rollback()
                raise


class RedisQuotaStorage(QuotaStorage):
    _RESERVE_SCRIPT = """
local counts = {}
local exceeded = 0
for i, key in ipairs(KEYS) do
  local current = tonumber(redis.call('GET', key) or '0')
  counts[i] = current
  if exceeded == 0 and current >= tonumber(ARGV[i]) then
    exceeded = i
  end
end
if exceeded ~= 0 then
  return {0, exceeded, unpack(counts)}
end
for i, key in ipairs(KEYS) do
  local current = redis.call('INCR', key)
  local ttl = tonumber(ARGV[#KEYS + i])
  if ttl and ttl > 0 then
    redis.call('EXPIRE', key, ttl)
  end
  counts[i] = current
end
return {1, 0, unpack(counts)}
"""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        config = config or {}
        try:
            import redis
        except ImportError as e:
            raise RuntimeError("redis storage requires installing hivemind-intent-quota-plugin[redis]") from e

        self._redis = redis
        self.key_prefix = str(config.get("key_prefix", "hivemind:intent-quota")).rstrip(":")
        self.cluster_hash_tag = self._clean_hash_tag(config.get("cluster_hash_tag"))
        if config.get("url"):
            self.client = redis.Redis.from_url(
                config["url"],
                **self._redis_kwargs(config),
            )
        elif config.get("cluster_nodes"):
            self.client = self._create_cluster_client(redis, config)
        else:
            self.client = redis.Redis(
                host=config.get("host", "127.0.0.1"),
                port=int(config.get("port", 6379)),
                db=int(config.get("db", 0)),
                **self._redis_kwargs(config),
            )

    @staticmethod
    def _redis_kwargs(config: Dict[str, Any]) -> Dict[str, Any]:
        kwargs: Dict[str, Any] = {"decode_responses": True}
        for key in (
            "username",
            "password",
            "ssl_certfile",
            "ssl_keyfile",
            "ssl_ca_certs",
            "ssl_cert_reqs",
        ):
            if config.get(key) is not None:
                kwargs[key] = config.get(key)
        if "ssl" in config or "use_ssl" in config:
            kwargs["ssl"] = bool(config.get("ssl", config.get("use_ssl", False)))
        if "ssl_check_hostname" in config:
            kwargs["ssl_check_hostname"] = bool(config.get("ssl_check_hostname", True))
        return kwargs

    @staticmethod
    def _clean_hash_tag(value: Any) -> Optional[str]:
        if value is None:
            return None
        tag = str(value).strip()
        if not tag:
            return None
        return tag.replace("{", "").replace("}", "")

    @staticmethod
    def _create_cluster_client(redis_module, config: Dict[str, Any]):
        from redis.cluster import ClusterNode

        nodes = []
        for node in config.get("cluster_nodes") or []:
            if isinstance(node, dict):
                nodes.append(
                    ClusterNode(
                        host=node.get("host", "127.0.0.1"),
                        port=int(node.get("port", 6379)),
                    )
                )
        if not nodes:
            raise ValueError("redis cluster storage requires at least one cluster node")
        return redis_module.RedisCluster(
            startup_nodes=nodes,
            username=config.get("username"),
            password=config.get("password"),
            ssl=bool(config.get("ssl", config.get("use_ssl", False))),
            ssl_certfile=config.get("ssl_certfile"),
            ssl_keyfile=config.get("ssl_keyfile"),
            ssl_ca_certs=config.get("ssl_ca_certs"),
            ssl_cert_reqs=config.get("ssl_cert_reqs", "required"),
            ssl_check_hostname=bool(config.get("ssl_check_hostname", True)),
            decode_responses=True,
        )

    def _slot_tag(self, identity: str) -> str:
        if self.cluster_hash_tag:
            return self.cluster_hash_tag
        return hashlib.sha256(identity.encode("utf-8")).hexdigest()

    def _key(self, identity: str, counter: QuotaCounter) -> str:
        return f"{self.key_prefix}:{{{self._slot_tag(identity)}}}:{identity}:{counter.key}"

    def get_subject_limit(self, hash_key: str, subject: str) -> Optional[int]:
        value = self.client.hget(hash_key, subject)
        if value is None or value == "":
            return None
        return int(value)

    def get_counts(self, identity: str, counters: Sequence[QuotaCounter]) -> Dict[str, int]:
        keys = [self._key(identity, counter) for counter in counters]
        values = self.client.mget(keys) if keys else []
        return {
            counter.key: int(value or 0)
            for counter, value in zip(counters, values)
        }

    def increment(self, identity: str, counters: Sequence[QuotaCounter]) -> Dict[str, int]:
        if not counters:
            return {}
        pipe = self.client.pipeline()
        for counter in counters:
            key = self._key(identity, counter)
            pipe.incr(key)
            if counter.reset_after > 0:
                pipe.expire(key, counter.reset_after)
        pipe.execute()
        return self.get_counts(identity, counters)

    def reserve(self, identity: str, counters: Sequence[QuotaCounter]) -> QuotaResult:
        if not counters:
            return QuotaResult(True, {})

        redis_keys = [self._key(identity, counter) for counter in counters]
        args = [counter.limit for counter in counters] + [counter.reset_after for counter in counters]
        response = self.client.eval(self._RESERVE_SCRIPT, len(redis_keys), *redis_keys, *args)
        allowed = bool(int(response[0]))
        exceeded_index = int(response[1])
        usage = {
            counter.key: int(value)
            for counter, value in zip(counters, response[2:])
        }
        if allowed:
            return QuotaResult(True, usage)
        return QuotaResult(False, usage, counters[exceeded_index - 1])


def create_storage(config: Optional[Dict[str, Any]] = None) -> QuotaStorage:
    config = dict(config or {})
    backend = str(config.get("backend", "sqlite")).lower()
    if backend in ("memory", "mem"):
        return MemoryQuotaStorage(config)
    if backend in ("json", "jsondb", "file"):
        return JsonQuotaStorage(config)
    if backend in ("sqlite", "sqlite3"):
        return SQLiteQuotaStorage(config)
    if backend == "redis":
        return RedisQuotaStorage(config)
    raise ValueError(f"Unknown quota storage backend: {backend}")
