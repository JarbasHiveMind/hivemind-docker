def add_client_database_refresh_forwarder(client_database_cls) -> bool:
    if hasattr(client_database_cls, "refresh"):
        return False

    def refresh(self, client_id):
        return self.db.refresh(client_id)

    client_database_cls.refresh = refresh
    return True


def install_core_compat() -> bool:
    try:
        from hivemind_core.database import ClientDatabase
    except Exception:
        return False

    return add_client_database_refresh_forwarder(ClientDatabase)
