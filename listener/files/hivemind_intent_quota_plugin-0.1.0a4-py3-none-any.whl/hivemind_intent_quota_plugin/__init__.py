from hivemind_intent_quota_plugin.compat import install_core_compat


install_core_compat()

from hivemind_intent_quota_plugin.policy import IntentQuotaPolicy
from hivemind_intent_quota_plugin.version import __version__


__all__ = ["IntentQuotaPolicy", "__version__"]
